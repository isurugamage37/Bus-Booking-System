<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class busSeat extends Model
{
    protected $table ='bus';
    protected $fillable =['seat_number','price'];

    
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class busRoute extends Model
{
    //

    protected $table ='bus_route';
    protected $fillable =['bus_id','route_id','status'];

}

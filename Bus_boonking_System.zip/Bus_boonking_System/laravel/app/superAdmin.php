<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;


class superAdmin extends Model
{
    use HasApiTokens,Notifiable;
  
//
    protected $table ='super_admin';
    protected $fillable = [
        'name', 'email', 'password',
    ];
}



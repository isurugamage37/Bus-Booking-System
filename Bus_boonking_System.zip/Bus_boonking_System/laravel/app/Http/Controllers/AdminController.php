<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\Auth;
use Illuminate\support\Facades\Hash;
use Carbon\Carbon;
use App\superAdmin;
use App\bus;
use App\busSeat;
use App\busSchedule;
use App\route;
use App\busRoute;
use App\busScheduleBooking;
class AdminController extends Controller
{
    //Admin register
    public function register(Request $request)
    {
       $data= $request->validate([
            'name'=>'required|string',
            'email'=>'required|string',
            'password'=>'required|string'
        ]);

       $superAdmin =superAdmin::create(
           [
               'name'=>$data['name'],
               'email'=>$data['email'],
               'password'=>Hash::make($data['password']),
           ]);

        
        $token=$superAdmin->createToken('registerToken')->plainTextToken;
        $response=[
            'superAdmin'=>$superAdmin,
            'token'=>$token,
        ];
      
       
        return response($response,201);

    }
    //Admin login
    public function login(request $request)
    {
        $data= $request->validate([
            'email'=>'required|string',
            'password'=>'required|string',
        ]);

        $superAdmin = superAdmin:: where('email',$data['email'])->first();
        if(!$superAdmin || !Hash::check($data['password'],$superAdmin->password)){
            return response(['message'=>'Unauthorized',401]);
        }else{
            $token =$superAdmin->createToken('loginToken')->plainTextToken;
            $response=[
                'superAdmin'=>$superAdmin,
                'token'=>$token,
            ];
            return response($response,200);
        }
    }

    public function logout()
    {
        auth()->superAdmin()->tokens()->delete();
        return response(['message'=>'Logged Out Successfully.']);
    }
    //paasword reset
    public function reset() {
        $credentials = request()->validate([
            'email' => 'required|string',
            'token' => 'required|string',
            'password' => 'required|string|confirmed'
        ]);

        $reset_password_status = Password::reset($credentials, function ($superAdmin, $password) {
            $superAdmin->password = $password;
            $superAdmin->save();
        });

        if ($reset_password_status == Password::INVALID_TOKEN) {
            return response()->json(["msg" => "Invalid token provided"], 400);
        }

        return response()->json(["msg" => "Password has been successfully changed"]);
    }

    Public function createbus(Request $request)
    {
        $bus= new bus();
 
        $bus->name = $request->input('name');
        $bus->type = $request->input('type');
        $bus->vehical_number = $request->input('vehical_number');
        $bus->save();
        return response()->json($bus);
    
 
    }
    // get all bus details
    Public function getbus()
    {
         $bus= bus::all();
         return response()->json($bus);
    }
 
    // get bus details by id
    public function getbusbyid($id)
    {
        $bus =bus::find($id);
        return response()->json($bus);
    }
    public function updatebusby(Request $request,$id)
    {
        $bus = bus::find($id);
        $bus->name = $request->input('name');
        $bus->type = $request->input('type');
        $bus->vehical_number = $request->input('vehical_number');
 
        $bus->save();
        return response()->json($bus);
 
 
    }
 
    public function deletebusby(Request $request,$id)
    {
        $bus = bus:: find($id);
        $bus->delete();
        return response()->json($bus);
    }

    //bus Schedule
    Public function createschedule(Request $request)
    {
        $busSchedule= new busSchedule();
        $busSchedule->bus_route_id = $request->input('bus_route_id');
        $busSchedule->direction = $request->input('direction');
        $busSchedule->start_timestamp = $request->input('start_timestamp');
        $busSchedule->end_timestamp = $request->input('end_timestamp');
        $busSchedule->save();
        return response()->json($busSchedule);
    
        
    }

  

    // Route
    Public function createRoute(Request $request)
    {
        $route= new route();
        $route->node_one = $request->input('node_one');
        $route->node_two = $request->input('node_two');
        $route->route_number = $request->input('route_number');
        $route->distance = $request->input('distance');
        $route->time = $request->input('time');
        $route->save();
        return response()->json($route);
    
        
    }

    //Bus Route
    Public function createBusRoute(Request $request)
    {
        $busRoute= new busRoute();
        $busRoute->bus_id = $request->input('bus_id');
        $busRoute->route_id = $request->input('route_id');
        $busRoute->status = $request->input('status');

        $busRoute->save();
        return response()->json($busRoute);
    
        
    }

    //test 
    public function createbus1(Request $request)
    {
       $data= $request->validate([
            'name'=>'required|string',
            'type'=>'required|string',
            'vehical_number'=>'required|string'
        ]);

       $bus =bus::create(
           [
               'name'=>$data['name'],
               'type'=>$data['type'],
               'vehical_number'=>Hash::make($data['vehical_number']),
           ]);

  
        $response=[
            'superAdmin'=>$superAdmin,
           
        ];
      
       
        return response($response,201);

    }
 
}

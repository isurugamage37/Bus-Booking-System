<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\Auth;
use Illuminate\support\Facades\Hash;
use Carbon\Carbon;
use App\User;
use App\busScheduleBooking;
use App\busSchedule;

class UserController extends Controller
{
  //user register
    public function register(Request $request)
    {
        
       $data= $request->validate([
            'name'=>'required|string',
            'email'=>'required|string',
            'password'=>'required|string'
        ]);

       $User =User::create(
           [
               'name'=>$data['name'],
               'email'=>$data['email'],
               'password'=>Hash::make($data['password']),
           ]);

    
        
        $token=$User->createToken('registerToken')->plainTextToken;
        $response=[
            'User'=>$User,
            'token'=>$token,
        ];
      
       
        return response($response,201);

    }
// user login
    public function login(request $request)
    {
        $data= $request->validate([
            'email'=>'required|string',
            'password'=>'required|string',
        ]);

        $User = User:: where('email',$data['email'])->first();
        if(!$User || !Hash::check($data['password'],$User->password)){
            return response(['message'=>'Unauthorized',401]);
        }else{
            $token =$User->createToken('loginToken')->plainTextToken;
            $response=[
                'superAdmin'=>$User,
                'token'=>$token,
            ];
            return response($response,200);
        }
    }

    public function logout()
    {
        auth()->superAdmin()->tokens()->delete();
        return response(['message'=>'Logged Out Successfully.']);
    }

    public function reset() {
        $credentials = request()->validate([
            'email' => 'required|string',
            'token' => 'required|string',
            'password' => 'required|string|confirmed'
        ]);

        $reset_password_status = Password::reset($credentials, function ($User, $password) {
            $User->password = $password;
            $User->save();
        });

        if ($reset_password_status == Password::INVALID_TOKEN) {
            return response()->json(["msg" => "Invalid token provided"], 400);
        }

        return response()->json(["msg" => "Password has been successfully changed"]);
    }

    //bus Details
    Public function getbus()
    {
         $bus= bus::all();
         return response()->json($bus);
    }
 
    //bus Details by id
    public function getbusbyid($id)
    {
        $bus =bus::find($id);
        return response()->json($bus);
    }
    // bus schedule
    Public function getbusSchedule()
    {
         $busSchedule= busSchedule::all();
         return response()->json($busSchedule);
    }

      //bus schedule Booking
      Public function createbusScheduleBooking(Request $request){
        $busScheduleBooking= new busScheduleBooking();
        $busScheduleBooking->bus_route_id = $request->input('bus_route_id');
        $busScheduleBooking->user_id = $request->input('user_id');
        $busScheduleBooking->bus_schedule_id = $request->input('bus_schedule_id');
        $busScheduleBooking->seat_number = $request->input('seat_number');
        $busScheduleBooking->price = $request->input('price');
        $busScheduleBooking->status = $request->input('status');
        $busScheduleBooking->save();
        return response()->json($busScheduleBooking);
    
        
    }
    //get booking details
    Public function getbusScheduleBooking()
    {
         $busScheduleBooking= busScheduleBooking::all();
         return response()->json($busScheduleBooking);
    }
    //get booking details by id
    public function deletebusScheduleBookingby(Request $request,$id)
    {
        $busScheduleBookingbus = bus:: find($id);
        $busScheduleBooking->delete();
        return response()->json($busScheduleBooking);
    }
}




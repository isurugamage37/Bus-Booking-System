<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class busSchedule extends Model
{
    protected $table ='bus_schedule';
    protected $fillable =['bus_route_id','direction','start_timestamp','end_timestamp'];


}

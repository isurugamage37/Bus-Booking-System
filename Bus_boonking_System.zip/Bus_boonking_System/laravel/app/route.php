<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class route extends Model
{
    //
    protected $table ='route';
    protected $fillable =['node_one','node_two','route_number','distance','time'];

 
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class busScheduleBooking extends Model
{
    protected $table ='bus_schedule_booking';
    protected $fillable =['bus_route_id','user_id','bus_schedule_id','seat_number','price','status'];


}

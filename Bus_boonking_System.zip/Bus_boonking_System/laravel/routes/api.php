<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\http\Conrollers\ApiController;
use App\http\Conrollers\ApiUserController;
use App\http\Conrollers\AdminController;
use App\http\Conrollers\UserController;



//Route::middleware('auth:api')->get('/user', function (Request $request) {
  //  return $request->user();
//});




Route::post('/loginAdmin','AdminController@login');
Route::post('/registerAdmin','AdminController@register');
Route::get('/getbus','AdminController@getbus');
Route::post('/postbus','AdminController@createbus');
Route::get('/getbus/{id}','AdminController@getbusbyid');
Route::put('/busupdate/{id}','AdminController@updatebusby');
Route::delete('/busdelete/{id}','AdminController@deletebusby');
Route::post('/postschedule', 'AdminController@createschedule');
Route::post('/postroute', 'AdminController@createRoute');
Route::post('/postbusroute', 'AdminController@createBusRoute');
Route::post('/postschedule', 'AdminController@createschedule');

Route::post('/loginUser','UserController@login');
Route::post('/registerUser','UserController@register');
Route::post('/postuser','UserController@createuser');
Route::post('/postbusScheduleBooking','UserController@createbusScheduleBooking');
Route::get('/getbusScheduleBooking','UserController@getbusScheduleBooking');
Route::delete('/deletebusScheduleBookingby/{id}','UserController@deletebusScheduleBookingby');
Route::get('/getbusSchedule','UserController@getbusSchedule');

Route::post('/logout','AdminController@logout');
Route::post('/reset', 'AdminController@reset');

Route::middleware(['auth:sanctum'])->group(function(){
       
       
        
        
       // Route::post('/postbus','AdminController@createbus');
        //Route::get('/getbus','AdminController@getbus');
        
        
       
        
      
    }
);
